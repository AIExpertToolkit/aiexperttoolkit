# AI Expert Toolkit — Site State
Last sync: (fill when you commit)
Base URL: https://aiexperttoolkit.com  <!-- or your Pages URL -->

Pages
- /index.html  → v1 (YYYY‑MM‑DD)
- /about.html  → v1
- /contact.html → v1
- /privacy-policy.html → v1
- /affiliate-disclosure.html → v1

Assets (optimized)
- /assets/img/home/ (hero-*.jpg|webp)
- /assets/img/cat/
- /assets/img/ui/
- /assets/img/logos/

Notes
- CI image pipeline: ON
- Next up: (fill)
